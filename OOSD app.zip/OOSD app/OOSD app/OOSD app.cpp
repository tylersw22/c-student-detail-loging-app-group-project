// OOSD_App_Tyler Shanu-Wilson_Jimmy Malandris.cpp : Defines the entry point for the console application.
//

// OOSD app.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include "stdio.h"
#include <string>
#include <iostream>
#include <stdlib.h>
#include <fstream>




using namespace std;
void StudentOptions(); //define functions
void CourseOptions();
void StudentEnrollment();
void AddRecord();
void ShowRecord();
void AddCourse();
void ShowCourse();
void ReadFromText();
int main()
{
	system("cls");
	int choice;

	cout << "*************************************\n";//menu user interface
	cout << "* Main Menu                         *\n";
	cout << "* ------------                      *\n";
	cout << "*                                   *\n";
	cout << "* 1.Student Options                 *\n";
	cout << "* 2.Course Options                  *\n";
	cout << "* 3.Enrol Student on Course         *\n";
	cout << "*                                   *\n";
	cout << "* 0. exit application               *\n";
	cout << "*************************************\n";
	cout << "Menu choice: ";

	cin >> choice;
	while ((choice < 0) || (choice > 3))
	{
		cout << "Please type again\n";
		cin >> choice;
	}
	switch (choice)//switch case- function called depends on user input
	{
	case 1:
		cout << "Student Menu\n";
		StudentOptions();
		break;
	case 2:
		cout << "Course Trial\n";
		CourseOptions();
		break;
	case 3:
		cout << "Student Enrollment\n";
		StudentEnrollment();
		break;
	case 0:
		break;
	}


	getchar();

	return 0;
}

void StudentOptions()
{

	int choice1;
	system("CLS"); // clears screen//

	cout << "*************************************\n";
	cout << "* Student Options                   *\n";
	cout << "* ------------                      *\n";
	cout << "*                                   *\n";
	cout << "* 1.Add Student Record              *\n";
	cout << "* 2.Show Student Record             *\n";
	cout << "* 3.Save Student Record             *\n";
	cout << "*                                   *\n";
	cout << "* 0. exit application               *\n";
	cout << "*************************************\n";
	cout << "Menu choice: ";
	cin >> choice1;
	while ((choice1 < 0) || (choice1 > 3))
	{
		cout << "Please type again\n";
		cin >> choice1;
	}
	switch (choice1)
	{
	case 1:AddRecord();
	case 2:ShowRecord();
	}

}

void CourseOptions()
{

	int choice2;
	system("CLS");

	cout << "*************************************\n";
	cout << "* Course Options                    *\n";
	cout << "* ------------                      *\n";
	cout << "*                                   *\n";
	cout << "* 1.Add New Course                  *\n";
	cout << "* 2.Show Course                     *\n";
	cout << "* 3.Save Course to file             *\n";
	cout << "* 4.Search Course Details           *\n";
	cout << "* 5.Amend Course details            *\n";
	cout << "*                                   *\n";
	cout << "* 0. exit application               *\n";
	cout << "*************************************\n";
	cout << "Menu choice: ";
	cin >> choice2;
	while ((choice2 < 0) || (choice2 > 5))
	{
		cout << "Please type again\n";
		cin >> choice2;
	}
	switch (choice2)
	{
	case 1:AddCourse();
	case 2:ShowCourse();

	}
}

void StudentEnrollment() 
{
	int choice3;
	system("CLS");
	cout << "*************************************\n";
	cout << "* Student Enrollment                *\n";
	cout << "* 1. Read from text file            *\n";
	cout << "*                                   *\n";
	cout << "*                                   *\n";
	cout << "*                                   *\n";
	cout << "* 0.exit application                *\n";
	cout << "*************************************\n";
	cout << "Menu choice: ";

	cin >> (choice3);
	while ((choice3 < 0) || (choice3 > 1))
	{
		cout << "Please type again\n";
		cin >> choice3;
	}
	switch (choice3)
	{
	case 1:ReadFromText();

	}
}

string ProgramOfStudy;
string CourseName;
char CourseLevel;
int EndYear;
int BeginYear;
int NoOfAssesments;
int NumGrade = 0;
int i = 0;
string AssesmentName[10];
int CourseworkWeighting[10];
int PortfolioWeighting[10];
int ExaminationWeighting[10];
int d[10];
int m[10];
int y[10];
void AddRecord()
{
	system("CLS");

	cout << ("What program are you studying?\n"); // First question
	cin >> ProgramOfStudy;
	cout << ("When does your program end (XXXX) \n"); // Second question
	cin >> EndYear;
	cout << ("When does you program start (XXXX)\n");
	cin >> BeginYear;

	while (EndYear - BeginYear > 4)
	{
		cout << ("One of the dates was wrong please type again the correct information\n"); //yearcheck
		cout << ("When does your program end (XXXX) \n");
		cin >> EndYear;
		cout << ("When does you program start (XXXX)\n");
		cin >> BeginYear;
	}
	cout << ("What is your course level\n");
	cin >> CourseLevel;
	while (CourseLevel != 'H' && CourseLevel != 'I' && CourseLevel != 'C')
	{
		cout << ("Please type the appropriate information (I,H,C)\n");
		cin >> CourseLevel;
	}
	cout << ("Please type in you course name\n");
	cin >> CourseName;

	cout << ("how many assesments on your course?\n");
	cin >> NoOfAssesments;

	cout << ("what is your overall numeric grade");
	cin >> NumGrade;
	while (NumGrade < 0 && NumGrade>100)
	{
		cout << ("must be between 0-100");
		cin >> NumGrade;
	}

	for (i = 0; i < NoOfAssesments; i++)
	{
		cout << ("what is your assesment name?\n");
		cin >> AssesmentName[i];
		cout << ("what is your assesment deadline date(DD/MM/YYYY)");
		cin >> d[i];
		cout << "/";
		cin >> m[i];
		cout << "/";
		cin >> y[i];

		while ((CourseworkWeighting[i] + PortfolioWeighting[i] + ExaminationWeighting[i]) != 100)
		{
			cout << ("what is your coursework weighting?\n");
			cin >> CourseworkWeighting[i];
			cout << ("what is your portfolio weighting?\n");
			cin >> PortfolioWeighting[i];
			cout << ("what is your examination weighting?\n");
			cin >> ExaminationWeighting[i];
			if ((CourseworkWeighting[i] + PortfolioWeighting[i] + ExaminationWeighting[i]) != 100)
			{
				cout << ("weighting must add up to 100% try again\n");
			}
			else
			{
				cout << ("weighting adds up to 100%. enter details of next assesment\n");
			}
		}
	}
	system("cls");
	main();
}

void ShowRecord()
{
	int x = 1;
	while (x != 0)
	{
		system("cls");
		cout << ("program of study: ");
		cout << (ProgramOfStudy);
		cout << ("\n start date: ");
		cout << (BeginYear);
		cout << ("\n end date: ");
		cout << (EndYear);
		cout << ("\n course level: ");
		cout << (CourseLevel);
		cout << ("\n course name: ");
		cout << (CourseName);
		for (i = 0; i <= NoOfAssesments; i++)
		{
			cout << ("\n ASSEMENT NAME: ");
			cout << (AssesmentName[i]);
			cout << ("\n assesment daedline date: ");
			cout << (d[i]);
			cout << ("/");
			cout << (m[i]);
			cout << ("/");
			cout << (y[i]);
			cout << ("\n coursework weighting: ");
			cout << (CourseworkWeighting[i]);
			cout << ("\n portfolio weighting: ");
			cout << (PortfolioWeighting[i]);
			cout << ("\n examination weighting: ");
			cout << (ExaminationWeighting[i]);
			cout << ("numeric grade: ");
			cout << (NumGrade);
			if (NumGrade < 40)
			{
				cout << ("fail");
			}
			else if (NumGrade >= 40 && NumGrade <= 49)
			{
				cout << ("your grade is E or D");
			}
			else if (NumGrade >= 50 && NumGrade <= 59)
			{
				cout << ("your grade is C or C+");
			}
			else if (NumGrade >= 60 && NumGrade <= 69)
			{
				cout << ("your grade is B or B+");
			}
			else
			{
				cout << ("your grade is A or A+");
			}
		}
		cout << ("\n type 0 to return to menu\n");
		cin >> (x);
	}
	system("cls");
	main();
}

int CourseCode = 0;
string CourseName1[10];
string CourseLevel1[10];
int Assesments[10];
void AddCourse()
{


	cout << ("course code: ");
	cout << (CourseCode);
	cout << ("\n what is the course name?");
	cin >> (CourseName1[CourseCode]);
	cout << ("\n what is the course level?");
	cin >> (CourseLevel1[CourseCode]);
	cout << ("\n how many assesments ?");
	cin >> (Assesments[CourseCode]);
	CourseCode = CourseCode + 1;
	system("cls");
	main();
}

void ShowCourse()
{
	int i = 0;
	for (i = 0; i < CourseCode; i++)
	{
		cout << ("\n---------------------");
		cout << ("\n course code: ");
		cout << (i);
		cout << ("\n course name: ");
		cout << (CourseName1[i]);
		cout << ("\n course level: ");
		cout << (CourseLevel1[i]);
		cout << ("\n number of assesments: ");
		cout << (Assesments[i]);
	}
}
string name[18];
void ReadFromText()
{


	{
		ifstream myFile;
		myFile.open("names.txt");


		for (i = 0; i < 18; i++) {
			myFile >> name[i];
			cout << "\n" << name[i];

		}
		getchar();
	}

}

